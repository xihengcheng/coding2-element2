class Particle{
  constructor(x, y, vel, acc, size, shape, decay){
    this.pos = createVector(x,y);
    this.vel = vel;
    this.acc = acc;
    this.size = size;
    this.lifetime = 255;
    this.decay = decay
    this.shape = shape;
  }
  
  finished(){
    return this.lifetime < 0;
    
  }
  
  accelerate(accel){
    this.acc.add(accel);
  }
  
  update(){
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.set(0,0);
    
    this.lifetime -= decay;
  }
  
  
  setColor(){ 
    let H;
    // H = random(0,this.lifetime)
    H = random(30*(this.lifetime/255)**5, 30)
    // H = random(0,30)

    let S = (255 - this.lifetime)*5
    let B = this.lifetime*6
    
    colorMode(HSB, 255);
    fill(H,S,B,this.lifetime);
    noStroke()
  }
  
    setColor2(){ 
   let H = 120; // 绿色的色调在 HSB 色彩模式中约为 120 度
  let S = 255; // 饱和度设为最大值
  let B = map(this.lifetime, 0, 255, 100, 255); // 亮度随生命周期变化，从灰色渐变到绿色
  
  colorMode(HSB, 255);
  fill(H, S, B, this.lifetime);
    noStroke()
  }
  
  
  getSize(){
    let size;
    size = this.size*2 * this.lifetime/255;
    return size 
  }
  
  
  spawnShape(){
    ellipse(this.pos.x,this.pos.y,this.getSize())
  }
  
  
  show(){
    
    this.setColor()
    this.spawnShape()
  }
  
    show2(){
    
    this.setColor2()
    this.spawnShape()
  }
  
}