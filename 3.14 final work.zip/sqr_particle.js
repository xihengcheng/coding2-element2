class SqrParticle extends Particle{
  spawnShape(){
    rectMode(CENTER)
    push()
    translate(this.pos.x,this.pos.y);
    rotate(random(TWO_PI));
    rect(0,0,this.size * 2);
    pop()
    
  }
}
