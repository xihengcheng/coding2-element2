class Cell {

  constructor(pos, r, c){
  if (pos) {
    this.pos = pos.copy();
  } else {
    this.pos = createVector(random(width), random(height), random(depth)); //坐标随机
  }

 this.r = r || 60;
this.c = c || color(random(100, 255), 0, random(100, 255), 100);
    
    ///////////////////////
    		this.position = createVector(random(width), random(height), random(depth));
		
		this.velocity = p5.Vector.random3D();
		this.velocity.setMag(random(2, 4));
		this.acceleration = createVector();
		this.maxForce = 0.2;
		this.maxSpeed = 10;
		this.color = {r : random(10, 255), g : random(10, 255), b : random(10, 255)};

		this.x = [],
		this.y = [],
		this.segNum = 20,
		this.segLength = 4;

		for (var i = 0; i < this.segNum; i++) {
			this.x[i] = 0;
			this.y[i] = 0;
		}
  
  }

  clicked(x, y) { //判定点击
    var d = dist(this.pos.x, this.pos.y, x, y);
    if (d < this.r) {
      return true;
    } else {
      return false;
    }
  }

  mitosis() { //缩小元球
    //this.pos.x += random(-this.r, this.r);
    var cell = new Cell(this.pos, this.r * 0.8, this.c); //调用了参数
    return cell;
  }

  move() { //元球移动
    var vel = p5.Vector.random2D();
    this.pos.add(vel);
  }

  show() { //元球显示
    noStroke();
    fill(this.c);
    ellipse(this.pos.x, this.pos.y, this.r, this.r)
  }
  
  
  
  
flock(cells, perception) {


		this.acceleration.mult(0);
		this.acceleration.add(0);
		this.acceleration.add(0);
		this.acceleration.add(0);
		this.acceleration.z *= 0.0001;
	}
  

edges() {
		if (this.pos.x < 0 || this.pos.x > width)
			this.velocity.x = 0 - this.velocity.x;
		
		if (this.pos.y < 0 || this.pos.y > height)
			this.velocity.y = 0 - this.velocity.y;
		
		if (this.pos.z < 1 || this.pos.z > depth)
			this.velocity.z = 0 - this.velocity.z;
		
		return;
		if (this.pos.x > width) {
			this.pos.x = 0;
		} else if (this.pos.x < 0) {
			this.pos.x = width;
		}
		if (this.pos.y > height) {
			this.pos.y = 0;
		} else if (this.pos.y < 0) {
			this.pos.y = height;
		}
	}

update() {
		this.pos.add(this.velocity);
		this.velocity.add(this.acceleration);
		this.velocity.limit(this.maxSpeed);
	}
  
show2() {

		strokeWeight(this.pos.z);
		
		this.dragSegment(0, this.pos.x, this.pos.y);
		
		for( var i= 0; i < this.x.length - 1; i++)
			this.dragSegment(i + 1, this.x[i], this.y[i]);
		
		

		//strokeWeight(8);
        noStroke();
       fill(random(100, 255), 0, random(100, 255), 100);
		//stroke(this.color.r, this.color.g, this.color.b);
		//point(this.position.x, this.position.y);
          ellipse(this.pos.x, this.pos.y, this.r, this.r);
	}

  show3() {

		strokeWeight(this.pos.z);
		
		this.dragSegment(0, this.pos.x, this.pos.y);
		
		for( var i= 0; i < this.x.length - 1; i++)
			this.dragSegment(i + 1, this.x[i], this.y[i]);
		
		

		//strokeWeight(8);
        noStroke();
       fill(random(100, 255), 0, random(100, 255), 100);
		//stroke(this.color.r, this.color.g, this.color.b);
		//point(this.position.x, this.position.y);
          ellipse(this.pos.x, this.pos.y, 60, 60);
	}
  
dragSegment(i, xin, yin) {
		var dx = xin - this.x[i];
		var dy = yin - this.y[i];
		var angle = atan2(dy, dx);
		this.x[i] = xin - cos(angle) * this.segLength;
		this.y[i] = yin - sin(angle) * this.segLength;
		this.segment(this.x[i], this.y[i], angle);
	  }  
  
segment(x, y, a) {
		push();
		translate(x, y);
		rotate(a);
		line(0, 0, this.segLength, 0);
		pop();
	  }
  
}