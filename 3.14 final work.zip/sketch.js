let walkers = [];
const smokeparticles = [];
var cells = [];
let particles = [];

let mousePos;
let hold;

let img;
let imgx = 100;
let imgy = 500;

let Clickcount = 0;
let t = 0;
let t2 = 0;

let alphaValue = 255; // 初始透明度值
////////////////////////////////////////////
let depth = 8;
let p = 10;
//////////////////////////////////

let particlesPerFrame;
let gravity;
let acc;
let vel;
let size;
let lifetime;
let pos;

let useMouse = true
////////////////////////////


let timer = 0;







function preload() {
  // 在setup()函数之前预加载图像
  img = loadImage('brain.jpg'); // 替换为你自己的图像路径
}

function setup() {
  background(0);
  let cnv = createCanvas(800, 800);
  cnv.mousePressed(() => hold = true);
  cnv.mouseReleased(() => hold = false);
  
  
  for (i = 0; i < 1500; i++){
    walkers.push(new Walker(random(150, width - 150), random(150, height - 150)));
  }
  
      cells.push(new Cell());
  ///////////////////////////////
      frameRate(60)

  
}

function draw() {
  background(0);
  

  
     tint(255, alphaValue); // 透明度为 alphaValue
  image(img,imgx, imgy, img.width / 4, img.height / 4);

  
  mousePos = createVector(mouseX, mouseY);
  //noStroke();
  for (const b in walkers){
    walkers[b].update();
    walkers[b].show();
    if (hold)
      applyForce(walkers[b]); 
  }
  
  
      if (Clickcount >= 2) {
      // 第二次点击时触发抖动效果
      shakeImage(img);
     halo();
    }

        if (Clickcount >= 3) {
      // 第二次点击时触发抖动效果
      moveImage(img);
    }
  
 let distance = dist(imgx, imgy, 600, 300)
 if(distance < 100){
   disappear();
   smoke();
 }
  
  //if(alphaValue = 0){
   // smoke();
 // }
     if(p === 0 ){ 
  for (var i = 0; i < cells.length; i++) {
     cells[i].move();// 元球抖动
    cells[i].show();
    //console.log(cells[i].pos.x);
    //cells[i].show2();
  }
   }
  else if(p === 1){
       for (var i = 0; i < cells.length; i++) {
    cells[i].flock(cells, 1);
    cells[i].edges();
    cells[i].update();
    cells[i].show();
  } 
   }
  else if(p === 2){
           for (var i = 0; i < cells.length; i++) {
    cells[i].flock(cells, 1);
    cells[i].edges();
    cells[i].update();
    cells[i].show3();
    
  }
  }
  
    else if(p === 4){
 gravity = createVector(0,0.);
  particlesPerFrame = 2;
  acc = createVector(0,0);
  acc.y = random(-3,3)
  acc.x = random(-3,3)
  vel = createVector(0,-0);
  size = 30;
  decay = 3;
  if (useMouse)
    pos = createVector(mouseX,mouseY);
  else
    pos = xMotion();
//-----------------------------// 
  
  background(0);
  
    for (let i = 0; i < particlesPerFrame; i++){
      particle = new Particle(
        pos.x,
        pos.y,
        vel,
        acc,
        size,
        decay);
      particles.push(particle);

      // particle = new SqrParticle(
      //   pos.x,
      //   pos.y,
      //   vel,
      //   acc,
      //   size,
      //   decay);
      // particles.push(particle);
    }
  
  
  for (let i = 0; i < particles.length; i++){
    
    particles[i].accelerate(gravity);
    particles[i].update();
    if (particles[i].finished()){
      particles.splice(i,1);
    }
    particles[i].show2();

    
  }
  }

    else if(p === 3){
 gravity = createVector(0,0.02);
  particlesPerFrame =1;
  acc = createVector(0,0);
  acc.y = random(-5,3)
  acc.x = random(-3,3)
  vel = createVector(0,-6);
  size = 30;
  decay = 3;
  if (useMouse)
    pos = createVector(mouseX,mouseY);
  else
      pos = createVector(width/2,height*9/10);
  // pos = motion();

  
//-----------------------------// 
  
  background(0);
  
  for(let i = 0; i < particlesPerFrame; i++){
    particle = new SqrParticle(
      pos.x,
      pos.y,
      vel,
      acc,
      size,
      decay);
    particles.push(particle);
    
    // particle = new Particle(
    //   pos.x,
    //   pos.y,
    //   vel,
    //   acc,
    //   size,
    //   decay);
    // particles.push(particle);
  }
  
  
  for (let i = 0; i < particles.length; i++){
    
    particles[i].accelerate(gravity);
    particles[i].update();
    if (particles[i].finished()){
      particles.splice(i,1);
    }
    particles[i].show();
  }
  }
  
}

function applyForce(w) {
    let dir = p5.Vector.sub(w.pos, mousePos);
    if (dir.mag() < 100)
      w.applyForce(dir);      
}

function mouseClicked() {
  if (mouseX >= 0 && mouseX <= img.width /4 && mouseY >= 500 && mouseY <= height - img.height/4) {
    walkers = []; // 清空移动的物体数组
      Clickcount += 1;
  }
  
}

function moveImage(img) {
  let dx = random(-10, 10);
  let dy = random(-10, 10);
  imgx = mouseX - img.width / 8 - dx;
  imgy = mouseY - img.height / 8 - dy;
 // image(img,100 + dx, 500 + dy, img.width / 4, img.height / 4);
  //image(img,mouseX - img.width / 8, mouseY - img.height / 8, img.width / 4, img.height / 4);
  //img.position(img.x + dx, img.y + dy);
}

function shakeImage(img) {
  // 在图片的位置上随机生成一个偏移量，并将图片移动到新的位置
  let dx = random(-10, 10);
  let dy = random(-10, 10);
  imgx = 100 - dx;
  imgy = 500 - dy;
 // image(img,100 + dx, 500 + dy, img.width / 4, img.height / 4);
  //image(img,mouseX - img.width / 8, mouseY - img.height / 8, img.width / 4, img.height / 4);
  //img.position(img.x + dx, img.y + dy);
}

function halo(){
  
    if (t) {
    return; // 如果停用，则直接返回，不执行后面的代码
  }
      for (let k = 0; k < 5; k++) {
    let size = sin(frameCount * 0.05 + k) * 50 + 50;
 let gray = map(k, 0, 4, 0, 255); // 使用 k 的映射值作为灰度值
  fill(gray); // 使用单一的灰度值填充
    ellipse(600, 300, size, size);
  }
  }

function disappear(){
  
t = 1;
   // 逐渐增加透明度值
  alphaValue -= 1;
   // 限制透明度值在 0 到 255 之间
  alphaValue = constrain(alphaValue, 0, 255);
  
  if(alphaValue <= 0){
    t2 = 1;
    p = 0;
  }
}

function smoke(){
      if (t2) {
    return; // 如果停用，则直接返回，不执行后面的代码
  }
    for (let i = 0; i < 5; i++) {
    let p = new Smokeparticle();
    smokeparticles.push(p);
  }
  for (let i = smokeparticles.length - 1; i >= 0; i--) {
    smokeparticles[i].update();
    smokeparticles[i].show();
    if (smokeparticles[i].finished()) {
      // remove this particle
      smokeparticles.splice(i, 1);
    }
  }
}

function xMotion(){
  let time = frameCount/40
  // let radius = width/2 * sin(frameCount/15)*0.5
  let x = sin(time) * width/3 + width/2;
  let y = sin(time*2)* height/3 + height/2;

  return createVector(x,y)  
}

function mousePressed() {
 for (var i = cells.length - 1; i >= 0; i--) {
    if (cells[i].clicked(mouseX, mouseY)) { //点击那个圆
      cells.push(cells[i].mitosis()); //形成一个更小的抖动的圆
      cells.push(cells[i].mitosis());

      cells.splice(i, 1); //去除原先的圆
    }
  }
}

function keyPressed() {
  if (keyCode === 32) {
 p = 1;
  } 
  
  if (key === 'p' || key === 'P') {
p = 2;
  }
  
    if (key === 'r' || key === 'R') {
p = 3;
  }
      if (key === 'g' || key === 'G') {
p = 4;
  }
  
}
