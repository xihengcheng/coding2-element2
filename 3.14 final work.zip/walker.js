class Walker{
    constructor(x, y){
        this.createRect(x, y);
        this.gravity = createVector(0, 0);
        this.wind = createVector(0,0);
        this.vel = p5.Vector.random2D();
        this.acc = p5.Vector.random2D();
        this.acc.setMag(0.001);
    }

    show(){
    let gray = (this.r + this.g + this.b) / 3; // 计算灰度值
    fill(gray); // 使用灰度值设置填充颜色
        rect(this.pos.x, this.pos.y, this.size)
    }

    update(){
        this.vel.add(this.acc);
        this.vel.limit(1);
        
        this.pos.add(this.vel);
        this.reflect();
    }

    applyForce(newAcc){
        this.acc = newAcc.setMag(0.2);
    }

    reflect(){
        if (this.pos.x + this.size > width){
            this.vel.x = this.vel.x * -1;
            this.acc.x = this.acc.x * -1;
        }
        else if (this.pos.x < 0){
            this.vel.x = this.vel.x * -1;
            this.acc.x = this.acc.x * -1;
        }
        
        if (this.pos.y + this.size > height){
            this.vel.y = this.vel.y * -1;
            this.acc.y = this.acc.y * -1;
        }
        else if (this.pos.y < 0){
            this.vel.y = this.vel.y * -1;
            this.acc.y = this.acc.y * -1;
        }
    }

    createRect(x, y){
       noStroke();
        this.pos = createVector(x, y);
        this.r = random(50, 110);
        this.g = random(50, 110);    
        this.b = 0;
        this.a = 100;
        
        this.size = random(12, 80);

        this.prob = random(0,1); 
        
        if (this.prob < 0.2)
            this.size = random(64, 128);
        else
            this.size = random(32, 64);
    }
}